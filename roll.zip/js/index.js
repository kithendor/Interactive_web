function newgame() {
	document.getElementById("tpp1").innerHTML = 0;
	document.getElementById("tpp2").innerHTML = 0;
	document.getElementById("cpp1").innerHTML = 0;
	document.getElementById("cpp2").innerHTML = 0;

	document.getElementById("d1").src="img/1.jpg";
	document.getElementById("d2").src="img/1.jpg";



}


function roll() {
	var dice1 =Math.floor(Math.random()*6+1);
	var dice2 =Math.floor(Math.random()*6+1);

	document.getElementById("d1").src="img/"+dice1+".jpg";
	document.getElementById("d2").src="img/"+dice2+".jpg";
}