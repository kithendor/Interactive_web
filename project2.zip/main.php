<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php

		session_start();

		if($_SESSION["fname"]==true)
		{
			echo "geia sou ".$_SESSION["fname"];
		}
		else {
			header("location:index.php");
		}

		


	?>
	<h1>Eimai i main selidoula!!!!!!!</h1>
	<a href="logout.php">Logout</a>

</body>
</html>