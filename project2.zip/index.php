<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<title></title>
</head>
<body>
<?php

 include("connect.php");

if(!empty($_POST))
  {

    $mail = $_POST["mail"];
    $pass = $_POST["pass"];

    $sel = "SELECT * FROM euserz WHERE email_db='$mail' && pass_db='$pass'";

     $resutl = $conn->query($sel);

     if($resutl->num_rows>0)
     {
        $row = $resutl->fetch_assoc();
        
            echo "Fname: ".$row['fname_db']." Lname: ".$row['lname_db'].
            "<br>";


            session_start();
            $_SESSION["fname"] = $row['fname_db'];

            header("location:main.php");

            

            // header("location:secret.php");
        
     }
     else
     {
       echo "den echw tipota";
     }
   }
   



?>
<div class="container">
<form method="POST" action="index.php">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="mail" placeholder="Enter email">

  </div>
  <div class="form-group">
    <label for="exampleInputPassword1">Password</label>
    <input type="password" class="form-control" name="pass" id="exampleInputPassword1" placeholder="Password">
  </div>

  <div class="form-group">
    <label for="exampleInputPassword1"><a href="register.php">Register</a></label>
  </div>
 
  <button type="submit" class="btn btn-primary">Submit</button>
</form>
</div>

</body>
</html>






