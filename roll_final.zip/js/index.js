var play_game = false;
var cur_player = 1;
var sum = 0;
var win_pnts;

function newgame() {

	win_pnts = Number(prompt("Sta posa?"));

	document.getElementById("tpp1").innerHTML = 0;
	document.getElementById("tpp2").innerHTML = 0;
	document.getElementById("cpp1").innerHTML = 0;
	document.getElementById("cpp2").innerHTML = 0;

	document.getElementById("pl2").classList.remove("actp");
	document.getElementById("pl1").classList.add("actp");

	document.getElementById("d1").src="img/1.jpg";
	document.getElementById("d2").src="img/1.jpg";

var cur_player = 1;
	play_game = true;
	sum = 0;
}

function roll() {
	if(play_game==true)
	{
		var dice1 =Math.floor(Math.random()*6+1);
		var dice2 =Math.floor(Math.random()*6+1);

		document.getElementById("d1").src="img/"+dice1+".jpg";
		document.getElementById("d2").src="img/"+dice2+".jpg";
		
		if(dice1==1 || dice2==1)
		{
			sum = 0;
			if(cur_player==1)
			{
				document.getElementById("tpp1").innerHTML = 0;
				document.getElementById("cpp1").innerHTML = 0;
				document.getElementById("pl1").classList.remove("actp");
				document.getElementById("pl2").classList.add("actp");
				cur_player = 2;

			}
			else
			{
				document.getElementById("tpp2").innerHTML = 0;
				document.getElementById("cpp2").innerHTML = 0;
				document.getElementById("pl2").classList.remove("actp");
				document.getElementById("pl1").classList.add("actp");
				cur_player = 1;
			}			
		}
		else
		{
			sum += dice2+dice1;
			if(cur_player==1)
			{
				document.getElementById("cpp1").innerHTML = sum;
			}
			else
			{
				document.getElementById("cpp2").innerHTML = sum;
			}

		}

	}
	
}

function holdf()
{
	if(play_game==true)
	{

		if(cur_player==1)
		{
			var cp1 = Number(document.getElementById("tpp1").innerHTML);
			document.getElementById("tpp1").innerHTML = cp1 + sum;
			cur_player = 2;
			document.getElementById("pl1").classList.remove("actp");
			document.getElementById("pl2").classList.add("actp");
			document.getElementById("cpp1").innerHTML = 0;

			if(Number(document.getElementById("tpp1").innerHTML)>=win_pnts)
			{
				alert("kerdise o 1");
				newgame();
			}
		}
		else
		{
			var cp2 = Number(document.getElementById("tpp2").innerHTML);
			document.getElementById("tpp2").innerHTML = cp2 + sum;
			cur_player = 1;
			document.getElementById("pl2").classList.remove("actp");
			document.getElementById("pl1").classList.add("actp");
			document.getElementById("cpp2").innerHTML = 0;
			if(Number(document.getElementById("tpp2").innerHTML)>=win_pnts)
			{
				alert("kerdise o 2");
				newgame();
			}
		}
	}

	sum = 0;
}